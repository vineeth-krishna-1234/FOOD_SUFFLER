import React, { Component } from 'react';
class Header extends Component {
    state = {  } 
    render() { 
        return (<div>hello
        </div>);
    }
}
 
export default Header;